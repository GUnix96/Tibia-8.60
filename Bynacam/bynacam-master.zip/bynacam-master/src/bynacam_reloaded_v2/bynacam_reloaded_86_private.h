/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef BYNACAM_RELOADED_86_PRIVATE_H
#define BYNACAM_RELOADED_86_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"2.0.0.0"
#define VER_MAJOR	2
#define VER_MINOR	0
#define VER_RELEASE	0
#define VER_BUILD	0
#define COMPANY_NAME	"ex0ticprgmr"
#define FILE_VERSION	"BynaCam Reloaded v2"
#define FILE_DESCRIPTION	"BynaCam DLL for Tibia 8.6"
#define INTERNAL_NAME	"bynacam.dll"
#define LEGAL_COPYRIGHT	"ex0ticprgmr & beziak"
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	"bynacam.dll"
#define PRODUCT_NAME	"BynaCam for Tibia 8.6"
#define PRODUCT_VERSION	"v2"

#endif /*BYNACAM_RELOADED_86_PRIVATE_H*/
